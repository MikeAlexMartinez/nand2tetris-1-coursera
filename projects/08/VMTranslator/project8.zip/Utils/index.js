const compose = require('./compose');

module.exports = {
  compose,
}
